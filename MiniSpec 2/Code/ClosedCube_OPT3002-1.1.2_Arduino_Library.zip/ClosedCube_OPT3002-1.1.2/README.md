ClosedCube Arduino Library for
ClosedCube OPT3002 Light to Digital Sensor Breakout 
=====================================================================================================

This is breakout board for [Texas Instruments OPT3002](http://www.ti.com/product/OPT3002) Light to Digital Sensor

[![](https://github.com/closedcube/ClosedCube_OPT3002_Arduino/blob/master/images/B061_OPT3002_Pic1.jpg)](https://www.tindie.com/stores/closedcube/)
[![](https://github.com/closedcube/ClosedCube_OPT3002_Arduino/blob/master/images/B061_OPT3002_Pic2.jpg)](https://www.tindie.com/stores/closedcube/)




